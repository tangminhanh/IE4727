<!DOCTYPE html>
<html>
<body>
<?php
echo "Hello, my first PHP script!";
?>
</body>
</html>