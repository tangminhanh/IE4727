<?php
$a=@(57/0);
echo '$a for (57/0) is '.$a."<br>";
$a=(57/5);
echo '$a for (57/5) is '.$a;
?>